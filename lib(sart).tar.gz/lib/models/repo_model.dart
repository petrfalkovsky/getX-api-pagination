class GitRepositoryModel {
  GitRepositoryModel({
    required this.fullName,
    required this.description,
    required this.url,
  });

  String fullName;
  String description;
  String url;

  factory GitRepositoryModel.fromJson(Map<String, dynamic> json) =>
      GitRepositoryModel(
        fullName: json['full_name'],
        description: json['description'] ?? 'No description',
        url: json['html_url'],
      );

  static List<GitRepositoryModel> listFromJson(list) =>
      List<GitRepositoryModel>.from(
          list.map((x) => GitRepositoryModel.fromJson(x)));
}
