import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:getx_p8n/controllers/repo_controller.dart';
import 'package:getx_p8n/models/repo_model.dart';

class GitRepositoryPage extends GetView<GitRepositoryController> {
  const GitRepositoryPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(title: const Text('Repositories')),
        body: Container(
          child: controller.obx(
            (state) => ListView.builder(
              controller: controller.scroll,
              itemCount: state?.length,
              itemBuilder: (context, index) {
                final GitRepositoryModel repository = state![index];
                return ListTile(
                  isThreeLine: true,
                  leading: Text(
                    (++index).toString(),
                    style: const TextStyle(fontSize: 20),
                  ),
                  title: Text(repository.fullName),
                  subtitle:
                      Text('${repository.description}\n${repository.url}'),
                );
              },
            ),
            onLoading: const Center(child: LinearProgressIndicator()),
            onEmpty: const Center(
              child: Text(
                'Repositories no found',
                style: TextStyle(fontSize: 18),
                textAlign: TextAlign.center,
              ),
            ),
            onError: (error) => Center(
              child: Text(
                'Error: Cannot get repositories \n$error',
                style: const TextStyle(fontSize: 18),
                textAlign: TextAlign.center,
              ),
            ),
          ),
        ));
  }
}
